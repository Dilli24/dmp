import { Component, OnInit } from '@angular/core';
import { GetTimeseriesDataService } from '../timeseries/get-timeseries-data.service';

@Component({
  selector: 'app-machineoperation',
  templateUrl: './machineoperation.component.html',
  styleUrls: ['./machineoperation.component.css']
})
export class MachineoperationComponent implements OnInit {

   url:string;
   status:string;
   cycle_cnt:any;
   tempData:any;
   pressData:any;
   type:string;
   title:string;
   data:any;
   type1:string;
   title1:string;
   data1:any;

  constructor(public timeseries:GetTimeseriesDataService) { 
      this.getCyclecount();
      this.getIngectionNozzleData();
      this.url="";
      this.status = "";
      this.type = 'LineChart';
      this.title = '';
      this.data = [];
      this.title1 = '';
      this.type1 = 'LineChart';
      this.data1 = [];

  }

  columnNames = ["Month", "Pressure"];
  options = {   
     hAxis: {
        title: 'Month'
     },
     vAxis:{
        title: 'Pressure'
     },
  };
  width = 450;
  height = 270;

  
  columnNames1= ["Month", "Temperature"];
  options1= {   
     hAxis1: {
        title1: 'Month'
     },
     vAxis1:{
        title1: 'Temperature'
     },
    pointSize:5
  };
  width1 = 450;
  height1 = 270;

  ngOnInit() {
  }

  getCyclecount(){

      this.timeseries.getToken().then((token) =>
         
         this.timeseries.getCycleCount(token).then(
            res => {
               console.log(token);
               this.status = this.timeseries.image_status;
               this.cycle_cnt = this.timeseries.cycle_cnt;
               if(this.status==="sad"){

                  this.url="../assets/images/sad.png";
               }
               else
               {
                  this.url="../assets/images/happy.png";
               }
            },
            err => {

            }
         )
      );
  }

  getIngectionNozzleData(){
      // this.timeseries.getInjectionNozzleData().then(
      //    res =>{
      //       console.log(this.timeseries.pressureData)
      //       this.pressData = this.timeseries.pressureData;
      //       this.tempData  = this.timeseries.temperatureData;
      //       this.data = this.pressData;
      //       this.data1 = this.tempData;
      //    },
      //    err => {

      //    }
      // );
      this.timeseries.getToken().then((token) =>
         this.timeseries.getInjectionNozzleData(token).then(
            res =>{
               console.log(this.timeseries.pressureData);
               this.pressData = this.timeseries.pressureData;
               this.tempData  = this.timeseries.temperatureData;
               // this.data = this.pressData;
               // this.data1 = this.tempData;
               this.data = [["Jan",  7.0],["Feb",  6.9],["Mar",  9.5],["Apr",  14.5],
                            ["May",  18.2],["Jun",  21.5],["Jul",  25.2],["Aug",  26.5],
                            ["Sep",  23.3],["Oct",  18.3],["Nov",  13.9],["Dec",  9.6]];
               this.data1 = [["Jan",  7.0],["Feb",  6.9],["Mar",  9.5],["Apr",  14.5],
               ["May",  18.2],["Jun",  21.5],["Jul",  25.2],["Aug",  26.5],
               ["Sep",  23.3],["Oct",  18.3],["Nov",  13.9],["Dec",  9.6]];
               
            },
            err => {
            }
         )
      );
  }

}
